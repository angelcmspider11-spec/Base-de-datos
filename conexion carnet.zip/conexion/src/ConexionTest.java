import java.sql.Connection;
import java.sql.DriverManager;

public class ConexionTest {
    public static void main(String[] args) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/mascota_db",
                "Angel2",
                "Videojuegos332"
            );

            System.out.println("✅ CONEXIÓN EXITOSA");

        } catch (Exception e) {
            System.out.println("❌ ERROR DE CONEXIÓN");
            e.printStackTrace();
        }
    }
}
