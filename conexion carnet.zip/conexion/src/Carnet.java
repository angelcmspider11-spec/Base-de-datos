/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
/**
 *
 * @author lalon
 */
public class Carnet extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Carnet.class.getName());

    /**
     * Creates new form Carnet
     */
   public Carnet() {
    initComponents();
    cargarEspecies();
    cargarEdades();
    cargarColores();
    cmbRaza.removeAllItems();
    cmbRaza.addItem("Seleccione una raza");
    eventoComboEspecie();
    cargarTablaMascotas();
}
public void cargarEspecies() {
    
    cmbEspecie.removeAllItems();
    cmbEspecie.addItem("Seleccione una especie");

    String sql = "SELECT nombre_especie FROM especies";

    try (Connection con = ConexionBD.conectar();
         PreparedStatement pst = con.prepareStatement(sql);
         ResultSet rs = pst.executeQuery()) {

        while (rs.next()) {
            cmbEspecie.addItem(rs.getString("nombre_especie"));
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error al cargar especies: " + e.getMessage());
    }
}
public void cargarEdades() {
    cmbEdad.removeAllItems();
    cmbEdad.addItem("Seleccione una edad");

    for (int i = 0; i <= 20; i++) {
        cmbEdad.addItem(String.valueOf(i));
    }
}
public void cargarColores() {   
    cmbColor1.removeAllItems();
    cmbColor2.removeAllItems();
    cmbColor3.removeAllItems();

    cmbColor1.addItem("Seleccione un color");
    cmbColor2.addItem("Sin seleccionar");
    cmbColor3.addItem("Sin seleccionar");

    String sql = "SELECT nombre_color FROM colores";

    try (Connection con = ConexionBD.conectar();
         PreparedStatement pst = con.prepareStatement(sql);
         ResultSet rs = pst.executeQuery()) {

        while (rs.next()) {
            String color = rs.getString("nombre_color");
            cmbColor1.addItem(color);
            cmbColor2.addItem(color);
            cmbColor3.addItem(color);
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error al cargar colores: " + e.getMessage());
    }
}
public int guardarDueno(String nombre, String apellido, String telefono) { 
    String sql = "INSERT INTO dueños (nombre, apellido, telefono) VALUES (?, ?, ?)";

    try (Connection con = ConexionBD.conectar();
         PreparedStatement pst = con.prepareStatement(sql, java.sql.Statement.RETURN_GENERATED_KEYS)) {

        pst.setString(1, nombre);
        pst.setString(2, apellido);
        pst.setString(3, telefono);

        int filas = pst.executeUpdate();

        if (filas > 0) {
            ResultSet rs = pst.getGeneratedKeys();
            if (rs.next()) {
                return rs.getInt(1);
            }
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error al guardar dueño: " + e.getMessage());
    }

    return -1;
}
public boolean actualizarDueno(int idDueno, String nombre, String apellido, String telefono) {
    String sql = "UPDATE dueños SET nombre = ?, apellido = ?, telefono = ? WHERE id_dueño = ?";

    try (Connection con = ConexionBD.conectar();
         PreparedStatement pst = con.prepareStatement(sql)) {

        pst.setString(1, nombre);
        pst.setString(2, apellido);
        pst.setString(3, telefono);
        pst.setInt(4, idDueno);

        return pst.executeUpdate() > 0;

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error al actualizar dueño: " + e.getMessage());
    }

    return false;
}
public int obtenerIdEspecie(String especie) {
    String sql = "SELECT id_especie FROM especies WHERE nombre_especie = ?";

    try (Connection con = ConexionBD.conectar();
         PreparedStatement pst = con.prepareStatement(sql)) {

        pst.setString(1, especie);
        ResultSet rs = pst.executeQuery();

        if (rs.next()) {
            return rs.getInt("id_especie");
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error al obtener id de especie: " + e.getMessage());
    }

    return -1;
}
public int obtenerIdRaza(String raza) {
    String sql = "SELECT id_raza FROM razas WHERE nombre_raza = ?";

    try (Connection con = ConexionBD.conectar();
         PreparedStatement pst = con.prepareStatement(sql)) {

        pst.setString(1, raza);
        ResultSet rs = pst.executeQuery();

        if (rs.next()) {
            return rs.getInt("id_raza");
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error al obtener id de raza: " + e.getMessage());
    }

    return -1;
}
public boolean actualizarMascota(int idMascota, String nombreMascota, String especie, String raza, String sexo, int edad) {
    String sql = "UPDATE mascotas SET nombre = ?, id_especie = ?, id_raza = ?, sexo = ?, edad = ? WHERE id_mascota = ?";

    try (Connection con = ConexionBD.conectar();
         PreparedStatement pst = con.prepareStatement(sql)) {

        int idEspecie = obtenerIdEspecie(especie);
        int idRaza = obtenerIdRaza(raza);

        pst.setString(1, nombreMascota);
        pst.setInt(2, idEspecie);
        pst.setInt(3, idRaza);
        pst.setString(4, sexo);
        pst.setInt(5, edad);
        pst.setInt(6, idMascota);

        return pst.executeUpdate() > 0;

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error al actualizar mascota: " + e.getMessage());
    }

    return false;
}
public int guardarMascota(int idDueno, String nombreMascota, String especie, String raza, String sexo, int edad) {
    String sql = "INSERT INTO mascotas (id_dueño, nombre, id_especie, id_raza, sexo, edad) VALUES (?, ?, ?, ?, ?, ?)";

    try (Connection con = ConexionBD.conectar();
         PreparedStatement pst = con.prepareStatement(sql, java.sql.Statement.RETURN_GENERATED_KEYS)) {

        int idEspecie = obtenerIdEspecie(especie);
        int idRaza = obtenerIdRaza(raza);

        pst.setInt(1, idDueno);
        pst.setString(2, nombreMascota);
        pst.setInt(3, idEspecie);
        pst.setInt(4, idRaza);
        pst.setString(5, sexo);
        pst.setInt(6, edad);

        int filas = pst.executeUpdate();

        if (filas > 0) {
            ResultSet rs = pst.getGeneratedKeys();
            if (rs.next()) {
                return rs.getInt(1);
            }
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error al guardar mascota: " + e.getMessage());
    }

    return -1;
}

public int obtenerIdColor(String color) {
    String sql = "SELECT id_color FROM colores WHERE nombre_color = ?";

    try (Connection con = ConexionBD.conectar();
         PreparedStatement pst = con.prepareStatement(sql)) {

        pst.setString(1, color);
        ResultSet rs = pst.executeQuery();

        if (rs.next()) {
            return rs.getInt("id_color");
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error al obtener id de color: " + e.getMessage());
    }

    return -1;
}
public boolean guardarColorMascota(int idMascota, int idColor) {
    String sql = "INSERT INTO mascota_colores (id_mascota, id_color) VALUES (?, ?)";

    try (Connection con = ConexionBD.conectar();
         PreparedStatement pst = con.prepareStatement(sql)) {

        pst.setInt(1, idMascota);
        pst.setInt(2, idColor);

        return pst.executeUpdate() > 0;

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error al guardar color de mascota: " + e.getMessage());
    }

    return false;
}
public boolean eliminarMascota(int idMascota) {
    String sql = "DELETE FROM mascotas WHERE id_mascota = ?";

    try (Connection con = ConexionBD.conectar();
         PreparedStatement pst = con.prepareStatement(sql)) {

        pst.setInt(1, idMascota);

        return pst.executeUpdate() > 0;

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error al eliminar mascota: " + e.getMessage());
    }

    return false;
}
public void cargarRazasPorEspecie(String especieSeleccionada) {
    cmbRaza.removeAllItems();
    cmbRaza.addItem("Seleccione una raza");

    String sql = "SELECT r.nombre_raza " +
                 "FROM razas r " +
                 "INNER JOIN especies e ON r.id_especie = e.id_especie " +
                 "WHERE e.nombre_especie = ?";

    try (Connection con = ConexionBD.conectar();
         PreparedStatement pst = con.prepareStatement(sql)) {

        pst.setString(1, especieSeleccionada);

        try (ResultSet rs = pst.executeQuery()) {
            while (rs.next()) {
                cmbRaza.addItem(rs.getString("nombre_raza"));
            }
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error al cargar razas: " + e.getMessage());
    }
}
public void cargarTablaMascotas() {
    javax.swing.table.DefaultTableModel modelo = new javax.swing.table.DefaultTableModel();

   modelo.addColumn("ID Mascota");
modelo.addColumn("ID Dueño");
modelo.addColumn("Dueño");
modelo.addColumn("Mascota");
modelo.addColumn("Edad");
modelo.addColumn("Sexo");
modelo.addColumn("Especie");
modelo.addColumn("Raza");

 String sql = "SELECT m.id_mascota, m.id_dueño, " +
             "CONCAT(d.nombre, ' ', d.apellido) AS dueno, " +
             "m.nombre AS mascota, " +
             "m.edad, " +
             "m.sexo, " +
             "e.nombre_especie, " +
             "r.nombre_raza " +
             "FROM mascotas m " +
             "INNER JOIN dueños d ON m.id_dueño = d.id_dueño " +
             "INNER JOIN especies e ON m.id_especie = e.id_especie " +
             "INNER JOIN razas r ON m.id_raza = r.id_raza";

    try (Connection con = ConexionBD.conectar();
         PreparedStatement pst = con.prepareStatement(sql);
         ResultSet rs = pst.executeQuery()) {

        while (rs.next()) {
      Object[] fila = new Object[8];
fila[0] = rs.getInt("id_mascota");
fila[1] = rs.getInt("id_dueño");
fila[2] = rs.getString("dueno");
fila[3] = rs.getString("mascota");
fila[4] = rs.getInt("edad");
fila[5] = rs.getString("sexo");
fila[6] = rs.getString("nombre_especie");
fila[7] = rs.getString("nombre_raza");
            modelo.addRow(fila);
        }

        tblMascotas.setModel(modelo);

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error al cargar tabla: " + e.getMessage());
    }
}
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroupSexo = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        cmbEspecie = new javax.swing.JComboBox<>();
        cmbRaza = new javax.swing.JComboBox<>();
        txtNombreDueno = new javax.swing.JTextField();
        txtApellidoDueno = new javax.swing.JTextField();
        txtTelefono = new javax.swing.JTextField();
        txtNombreMascota = new javax.swing.JTextField();
        cmbEdad = new javax.swing.JComboBox<>();
        btnGuardar = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();
        rbtnMacho = new javax.swing.JRadioButton();
        rbtnHembra = new javax.swing.JRadioButton();
        cmbColor1 = new javax.swing.JComboBox<>();
        cmbColor2 = new javax.swing.JComboBox<>();
        cmbColor3 = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        txtIdMascota = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblMascotas = new javax.swing.JTable();
        btnActualizar = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Carnet de Animales");

        cmbEspecie.addActionListener(this::cmbEspecieActionPerformed);

        cmbRaza.addActionListener(this::cmbRazaActionPerformed);

        txtNombreDueno.setText("Nombre del dueño o dueña");
        txtNombreDueno.addActionListener(this::txtNombreDuenoActionPerformed);

        txtApellidoDueno.setText("Apellidos del dueño o dueña");
        txtApellidoDueno.addActionListener(this::txtApellidoDuenoActionPerformed);

        txtTelefono.setText("Telefono");

        txtNombreMascota.setText("Nombre de la mascota");

        btnGuardar.setText("Guardar");
        btnGuardar.addActionListener(this::btnGuardarActionPerformed);

        btnLimpiar.setText("Limpiar");
        btnLimpiar.addActionListener(this::btnLimpiarActionPerformed);

        buttonGroupSexo.add(rbtnMacho);
        rbtnMacho.setText("Macho");

        buttonGroupSexo.add(rbtnHembra);
        rbtnHembra.setText("Hembra");

        cmbColor1.addActionListener(this::cmbColor1ActionPerformed);

        jButton1.setText("Eliminar");
        jButton1.addActionListener(this::jButton1ActionPerformed);

        txtIdMascota.addActionListener(this::txtIdMascotaActionPerformed);

        jLabel2.setText("ID de mascota a eliminar");

        tblMascotas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        tblMascotas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblMascotasMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblMascotas);

        btnActualizar.setText("Actualizar");
        btnActualizar.addActionListener(this::btnActualizarActionPerformed);

        jLabel3.setText("Nombre de las mascota");

        jLabel4.setText("Telefono");

        jLabel5.setText("Apellidos del dueño o dueña");

        jLabel6.setText("Nombre del dueño o dueña");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(161, 161, 161)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(6, 6, 6)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(btnGuardar)
                                            .addGap(54, 54, 54)
                                            .addComponent(btnLimpiar)
                                            .addGap(52, 52, 52)
                                            .addComponent(btnActualizar))
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(txtIdMascota, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(31, 31, 31)
                                            .addComponent(jButton1))))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(cmbColor1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(52, 52, 52)
                                    .addComponent(cmbColor2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(52, 52, 52)
                                    .addComponent(cmbColor3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(rbtnMacho, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(61, 61, 61)
                                    .addComponent(rbtnHembra, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGap(39, 39, 39))
                        .addComponent(cmbEdad, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(cmbEspecie, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(cmbRaza, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtNombreMascota)
                        .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtTelefono)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 377, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtApellidoDueno)
                        .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtNombreDueno)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 39, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(48, 48, 48))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(19, 19, 19)
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtNombreDueno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel5)
                        .addGap(5, 5, 5)
                        .addComponent(txtApellidoDueno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel4)
                        .addGap(7, 7, 7)
                        .addComponent(txtTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtNombreMascota, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(42, 42, 42)
                        .addComponent(cmbEdad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(40, 40, 40)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(rbtnMacho)
                            .addComponent(rbtnHembra))
                        .addGap(29, 29, 29)
                        .addComponent(cmbEspecie, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(cmbRaza, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cmbColor1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cmbColor2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cmbColor3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(78, 78, 78)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 58, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnGuardar)
                    .addComponent(btnLimpiar)
                    .addComponent(btnActualizar))
                .addGap(40, 40, 40)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtIdMascota, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1)
                    .addComponent(jLabel2))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cmbEspecieActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbEspecieActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbEspecieActionPerformed

    private void cmbRazaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbRazaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbRazaActionPerformed

    private void txtNombreDuenoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreDuenoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombreDuenoActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
String nombre = txtNombreDueno.getText();
String apellido = txtApellidoDueno.getText();
String telefono = txtTelefono.getText();
String mascota = txtNombreMascota.getText();

String edadTexto = cmbEdad.getSelectedItem().toString();
String especie = cmbEspecie.getSelectedItem().toString();
String raza = cmbRaza.getSelectedItem().toString();

String color1 = cmbColor1.getSelectedItem().toString();
String color2 = cmbColor2.getSelectedItem().toString();
String color3 = cmbColor3.getSelectedItem().toString();

String sexo = "";
if (rbtnMacho.isSelected()) {
    sexo = "Macho";
} else if (rbtnHembra.isSelected()) {
    sexo = "Hembra";
}

if (nombre.isEmpty() || apellido.isEmpty() || telefono.isEmpty() || mascota.isEmpty()) {
    JOptionPane.showMessageDialog(this, "Completa todos los campos");
    return;
}

if (edadTexto.equals("Seleccione una edad")) {
    JOptionPane.showMessageDialog(this, "Selecciona una edad");
    return;
}

if (especie.equals("Seleccione una especie")) {
    JOptionPane.showMessageDialog(this, "Selecciona una especie");
    return;
}

if (raza.equals("Seleccione una raza")) {
    JOptionPane.showMessageDialog(this, "Selecciona una raza");
    return;
}

if (sexo.isEmpty()) {
    JOptionPane.showMessageDialog(this, "Selecciona el sexo");
    return;
}

if (color1.equals("Seleccione un color")) {
    JOptionPane.showMessageDialog(this, "Selecciona al menos un color");
    return;
}

int edad = Integer.parseInt(edadTexto);

int idDueno = guardarDueno(nombre, apellido, telefono);

if (idDueno != -1) {
    int idMascota = guardarMascota(idDueno, mascota, especie, raza, sexo, edad);

    if (idMascota != -1) {
        int idColor1 = obtenerIdColor(color1);
        if (idColor1 != -1) {
            guardarColorMascota(idMascota, idColor1);
        }

        if (!color2.equals("Sin seleccionar")) {
            int idColor2 = obtenerIdColor(color2);
            if (idColor2 != -1) {
                guardarColorMascota(idMascota, idColor2);
            }
        }

        if (!color3.equals("Sin seleccionar")) {
            int idColor3 = obtenerIdColor(color3);
            if (idColor3 != -1) {
                guardarColorMascota(idMascota, idColor3);
            }
        }

        JOptionPane.showMessageDialog(this, "Datos guardados correctamente");
        cargarTablaMascotas();
        btnLimpiarActionPerformed(null);

    } else {
        JOptionPane.showMessageDialog(this, "No se pudo guardar la mascota");
    }

} else {
    JOptionPane.showMessageDialog(this, "No se pudo guardar el dueño");
}
// TODO add your handling code here:
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void cmbColor1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbColor1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbColor1ActionPerformed

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
txtNombreDueno.setText("");
txtApellidoDueno.setText("");
txtTelefono.setText("");
txtNombreMascota.setText("");

cmbEdad.setSelectedIndex(0);
cmbEspecie.setSelectedIndex(0);
cmbRaza.removeAllItems();
cmbRaza.addItem("Seleccione una raza");

cmbColor1.setSelectedIndex(0);
cmbColor2.setSelectedIndex(0);
cmbColor3.setSelectedIndex(0);

buttonGroupSexo.clearSelection();
// TODO add your handling code here:
    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

    int fila = tblMascotas.getSelectedRow();

    if (fila < 0) {
        JOptionPane.showMessageDialog(this, "Selecciona una mascota");
        return;
    }

    int id = Integer.parseInt(tblMascotas.getValueAt(fila, 0).toString());

    int confirmacion = JOptionPane.showConfirmDialog(
            this,
            "¿Seguro que deseas eliminar esta mascota?",
            "Confirmar eliminación",
            JOptionPane.YES_NO_OPTION
    );

    if (confirmacion != JOptionPane.YES_OPTION) {
        return;
    }

    String sql = "DELETE FROM mascotas WHERE id_mascota = ?";

    try (Connection con = ConexionBD.conectar();
         PreparedStatement pst = con.prepareStatement(sql)) {

        pst.setInt(1, id);
        pst.executeUpdate();

        JOptionPane.showMessageDialog(this, "Mascota eliminada correctamente");

        cargarTablaMascotas();

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error al eliminar: " + e.getMessage());
    }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void txtApellidoDuenoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtApellidoDuenoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtApellidoDuenoActionPerformed

    private void tblMascotasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblMascotasMouseClicked

    int fila = tblMascotas.getSelectedRow();

    if (fila >= 0) {
        txtIdMascota.setText(tblMascotas.getValueAt(fila, 0).toString());

        String nombreCompleto = tblMascotas.getValueAt(fila, 2).toString();
        String[] partes = nombreCompleto.split(" ", 2);

        if (partes.length > 0) {
            txtNombreDueno.setText(partes[0]);
        }
        if (partes.length > 1) {
            txtApellidoDueno.setText(partes[1]);
        }

        txtNombreMascota.setText(tblMascotas.getValueAt(fila, 3).toString());

        String edad = tblMascotas.getValueAt(fila, 4).toString();
        cmbEdad.setSelectedItem(edad);

        String sexo = tblMascotas.getValueAt(fila, 5).toString();
        if (sexo.equals("Macho")) {
            rbtnMacho.setSelected(true);
        } else if (sexo.equals("Hembra")) {
            rbtnHembra.setSelected(true);
        }

        String especie = tblMascotas.getValueAt(fila, 6).toString();
        cmbEspecie.setSelectedItem(especie);

        cargarRazasPorEspecie(especie);

        String raza = tblMascotas.getValueAt(fila, 7).toString();
        cmbRaza.setSelectedItem(raza);
    }
    }//GEN-LAST:event_tblMascotasMouseClicked

    private void txtIdMascotaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdMascotaActionPerformed
     String idTexto = txtIdMascota.getText();
String mascota = txtNombreMascota.getText();
String edadTexto = cmbEdad.getSelectedItem().toString();
String especie = cmbEspecie.getSelectedItem().toString();
String raza = cmbRaza.getSelectedItem().toString();

String sexo = "";
if (rbtnMacho.isSelected()) {
    sexo = "Macho";
} else if (rbtnHembra.isSelected()) {
    sexo = "Hembra";
}

if (idTexto.isEmpty()) {
    JOptionPane.showMessageDialog(this, "Selecciona una mascota");
    return;
}

int idMascota = Integer.parseInt(idTexto);
int edad = Integer.parseInt(edadTexto);

boolean actualizado = actualizarMascota(idMascota, mascota, especie, raza, sexo, edad);

if (actualizado) {
    JOptionPane.showMessageDialog(this, "Actualizado correctamente");
    cargarTablaMascotas();
} else {
    JOptionPane.showMessageDialog(this, "Error al actualizar");
}
    }//GEN-LAST:event_txtIdMascotaActionPerformed

    private void btnActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarActionPerformed
int fila = tblMascotas.getSelectedRow();

if (fila < 0) {
    JOptionPane.showMessageDialog(this, "Selecciona una mascota");
    return;
}

int idMascota = Integer.parseInt(tblMascotas.getValueAt(fila, 0).toString());
int idDueno = Integer.parseInt(tblMascotas.getValueAt(fila, 1).toString());

String nombreDueno = txtNombreDueno.getText().trim();
String apellidoDueno = txtApellidoDueno.getText().trim();
String telefono = txtTelefono.getText().trim();
String mascota = txtNombreMascota.getText().trim();

String edadTexto = cmbEdad.getSelectedItem().toString();
String especie = cmbEspecie.getSelectedItem().toString();
String raza = cmbRaza.getSelectedItem().toString();

String sexo = "";
if (rbtnMacho.isSelected()) {
    sexo = "Macho";
} else if (rbtnHembra.isSelected()) {
    sexo = "Hembra";
}

if (nombreDueno.isEmpty() || apellidoDueno.isEmpty() || mascota.isEmpty()) {
    JOptionPane.showMessageDialog(this, "No dejes campos importantes vacíos");
    return;
}

int edad = Integer.parseInt(edadTexto);

boolean duenoActualizado = actualizarDueno(idDueno, nombreDueno, apellidoDueno, telefono);
boolean mascotaActualizada = actualizarMascota(idMascota, mascota, especie, raza, sexo, edad);

if (duenoActualizado && mascotaActualizada) {
    JOptionPane.showMessageDialog(this, "Actualizado correctamente");
    cargarTablaMascotas();
} else {
    JOptionPane.showMessageDialog(this, "Error al actualizar");
}
    }//GEN-LAST:event_btnActualizarActionPerformed
private void eventoComboEspecie() {
    cmbEspecie.addActionListener(e -> {
        Object seleccionado = cmbEspecie.getSelectedItem();

        if (seleccionado != null) {
            String especie = seleccionado.toString();

            if (!especie.equals("Seleccione una especie")) {
                cargarRazasPorEspecie(especie);
            } else {
                cmbRaza.removeAllItems();
                cmbRaza.addItem("Seleccione una raza");
            }
        }
    });
}
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Carnet().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnActualizar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.ButtonGroup buttonGroupSexo;
    private javax.swing.JComboBox<String> cmbColor1;
    private javax.swing.JComboBox<String> cmbColor2;
    private javax.swing.JComboBox<String> cmbColor3;
    private javax.swing.JComboBox<String> cmbEdad;
    private javax.swing.JComboBox<String> cmbEspecie;
    private javax.swing.JComboBox<String> cmbRaza;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JRadioButton rbtnHembra;
    private javax.swing.JRadioButton rbtnMacho;
    private javax.swing.JTable tblMascotas;
    private javax.swing.JTextField txtApellidoDueno;
    private javax.swing.JTextField txtIdMascota;
    private javax.swing.JTextField txtNombreDueno;
    private javax.swing.JTextField txtNombreMascota;
    private javax.swing.JTextField txtTelefono;
    // End of variables declaration//GEN-END:variables
}
