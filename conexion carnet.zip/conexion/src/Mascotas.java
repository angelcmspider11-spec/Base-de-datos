import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import javax.swing.*;
import java.awt.*;

public class Mascotas {

    private static final String URL = "jdbc:mysql://localhost:3306/mascota_db";
    private static final String USUARIO = "Angel2";
    private static final String CONTRASENA = "Videojuegos332";

    private Connection conexion;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Mascotas app = new Mascotas();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            app.conexion = DriverManager.getConnection(URL, USUARIO, CONTRASENA);
            System.out.println("Conectado a la BD");

            System.out.println("\n===== DATOS DEL DUEÑO =====");
            System.out.print("Nombre del dueño: ");
            String nombreDueno = scanner.nextLine();

            System.out.print("Apellido del dueño: ");
            String apellidoDueno = scanner.nextLine();

            System.out.print("Teléfono: ");
            String telefono = scanner.nextLine();

            int idDueno = app.registrarDueno(nombreDueno, apellidoDueno, telefono);
            System.out.println("Dueño registrado con ID: " + idDueno);

            System.out.println("\n===== REGISTRAR NUEVA MASCOTA =====");

            System.out.println("\nSELECCIONA TIPO:");
            System.out.println("1. Perro");
            System.out.println("2. Gato");
            System.out.print("Elige una opción: ");
            int idEspecie = scanner.nextInt();

            System.out.println("\nSELECCIONA RAZA:");
            List<String> listaRazas = app.obtenerRazasPorEspecie(idEspecie);
            for (int i = 0; i < listaRazas.size(); i++) {
                System.out.println((i + 1) + ". " + listaRazas.get(i));
            }
            System.out.print("Escribe el número de la raza: ");
            int opcionRaza = scanner.nextInt();

            int idRaza;
            if (idEspecie == 1) {
                idRaza = opcionRaza;
            } else {
                idRaza = opcionRaza + 20;
            }

            System.out.print("\nNombre de la mascota: ");
            scanner.nextLine();
            String nombre = scanner.nextLine();

            System.out.print("Edad: ");
            int edad = scanner.nextInt();

            System.out.println("\nSEXO:");
            System.out.println("1. Macho");
            System.out.println("2. Hembra");
            System.out.print("Opción: ");
            int opcionSexo = scanner.nextInt();
            String sexo = (opcionSexo == 1) ? "Macho" : "Hembra";

            List<Integer> listaIdsColores = new ArrayList<>();
            List<String> listaNombresColores = new ArrayList<>();
            boolean seguirAgregando = true;
            int contadorColores = 0;

            List<String> nombresColoresBD = new ArrayList<>();
            List<String> codigosHexBD = new ArrayList<>();

            String sqlColores = "SELECT id_color, nombre_color, codigo_hex FROM colores";
            Statement stmtColores = app.conexion.createStatement();
            ResultSet rsTodosColores = stmtColores.executeQuery(sqlColores);

            while (rsTodosColores.next()) {
                nombresColoresBD.add(rsTodosColores.getString("nombre_color"));
                codigosHexBD.add(rsTodosColores.getString("codigo_hex"));
            }

            while (seguirAgregando && contadorColores < 3) {
                System.out.println("\nSelecciona color " + (contadorColores + 1));

                int idColorSeleccionado = app.mostrarPaletaColores(nombresColoresBD, codigosHexBD);

                if (idColorSeleccionado != -1) {
                    listaIdsColores.add(idColorSeleccionado);
                    listaNombresColores.add(nombresColoresBD.get(idColorSeleccionado - 1));
                    contadorColores++;

                    if (contadorColores < 3) {
                        System.out.print("¿Desea agregar otro color? (S/N): ");
                        scanner.nextLine();
                        String respuesta = scanner.nextLine().trim().toUpperCase();

                        if (!respuesta.equals("S") && !respuesta.equals("SI")) {
                            seguirAgregando = false;
                        }
                    } else {
                        System.out.println("Máximo de 3 colores alcanzado.");
                    }
                } else {
                    seguirAgregando = false;
                }
            }

            if (listaIdsColores.isEmpty()) {
                System.out.println("No seleccionaste ningún color.");
            }

            System.out.println("\nGuardando...");
            int idMascotaGenerado = app.registrarMascota(idDueno, nombre, idEspecie, idRaza, sexo, edad);

            if (idMascotaGenerado != -1) {
                System.out.println("Datos principales guardados");

                for (int idColor : listaIdsColores) {
                    app.agregarColorAMascotaSimple(idMascotaGenerado, idColor);
                }
                System.out.println("Colores asignados correctamente");

                System.out.println("\n====================================");
                System.out.println("REGISTRO COMPLETO:");
                app.obtenerInfoMascota(idMascotaGenerado);

                System.out.println("\nCOLORES DE LA MASCOTA:");
                if (listaNombresColores.isEmpty()) {
                    System.out.println("Sin color especificado");
                } else {
                    for (String color : listaNombresColores) {
                        System.out.println("- " + color);
                    }
                }
                System.out.println("====================================");
            }

            app.cerrar();

        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public int registrarDueno(String nombre, String apellido, String telefono) {
        String sql = "INSERT INTO dueños (nombre, apellido, telefono) VALUES (?, ?, ?)";

        try {
            PreparedStatement pst = conexion.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            pst.setString(1, nombre);
            pst.setString(2, apellido);
            pst.setString(3, telefono);

            int resultado = pst.executeUpdate();

            if (resultado > 0) {
                ResultSet rs = pst.getGeneratedKeys();
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
            return -1;
        } catch (SQLException e) {
            System.out.println("Error al registrar dueño: " + e.getMessage());
            return -1;
        }
    }

    public int mostrarPaletaColores(List<String> nombres, List<String> hexCodes) {
        JFrame frame = new JFrame("Selecciona un Color");
        frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        frame.setSize(450, 300);
        frame.setLayout(new GridLayout(0, 5, 8, 8));
        frame.setLocationRelativeTo(null);
        frame.setAlwaysOnTop(true);

        final int[] selectedId = {-1};

        for (int i = 0; i < nombres.size(); i++) {
            JButton boton = new JButton();
            boton.setText("<html><center>" + nombres.get(i) + "</center></html>");

            Color color = Color.decode(hexCodes.get(i));
            boton.setBackground(color);

            int r = color.getRed();
            int g = color.getGreen();
            int b = color.getBlue();
            double luminancia = (0.299 * r + 0.587 * g + 0.114 * b);
            boton.setForeground(luminancia < 128 ? Color.WHITE : Color.BLACK);

            final int idFinal = i + 1;
            boton.addActionListener(e -> {
                selectedId[0] = idFinal;
                frame.dispose();
            });

            frame.add(boton);
        }

        frame.setVisible(true);

        while (selectedId[0] == -1) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException ex) {
            }
        }

        return selectedId[0];
    }

    public int registrarMascota(int idDueno, String nombre, int idEspecie,
                                int idRaza, String sexo, int edad) {
        String sql = "INSERT INTO mascotas (id_dueño, nombre, id_especie, id_raza, sexo, edad) VALUES (?, ?, ?, ?, ?, ?)";

        try {
            PreparedStatement pst = conexion.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            pst.setInt(1, idDueno);
            pst.setString(2, nombre);
            pst.setInt(3, idEspecie);
            pst.setInt(4, idRaza);
            pst.setString(5, sexo);
            pst.setInt(6, edad);

            int resultado = pst.executeUpdate();

            if (resultado > 0) {
                ResultSet rs = pst.getGeneratedKeys();
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
            return -1;
        } catch (SQLException e) {
            System.out.println("Error al registrar mascota: " + e.getMessage());
            return -1;
        }
    }

    public List<String> obtenerRazasPorEspecie(int idEspecie) {
        List<String> razas = new ArrayList<>();
        String sql = "SELECT nombre_raza FROM razas WHERE id_especie = ?";

        try {
            PreparedStatement pst = conexion.prepareStatement(sql);
            pst.setInt(1, idEspecie);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                razas.add(rs.getString("nombre_raza"));
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener razas: " + e.getMessage());
        }

        return razas;
    }

    public boolean agregarColorAMascotaSimple(int idMascota, int idColor) {
        String sql = "INSERT INTO mascota_colores (id_mascota, id_color) VALUES (?, ?)";

        try {
            PreparedStatement pst = conexion.prepareStatement(sql);
            pst.setInt(1, idMascota);
            pst.setInt(2, idColor);

            int resultado = pst.executeUpdate();
            return resultado > 0;
        } catch (SQLException e) {
            System.out.println("Error al agregar color: " + e.getMessage());
            return false;
        }
    }

    public void obtenerInfoMascota(int idMascota) {
        String sql = "SELECT m.nombre, d.nombre as dueno_nombre, d.apellido, e.nombre_especie, " +
                     "r.nombre_raza, m.sexo, m.edad " +
                     "FROM mascotas m " +
                     "JOIN dueños d ON m.id_dueño = d.id_dueño " +
                     "JOIN especies e ON m.id_especie = e.id_especie " +
                     "JOIN razas r ON m.id_raza = r.id_raza " +
                     "WHERE m.id_mascota = ?";

        try {
            PreparedStatement pst = conexion.prepareStatement(sql);
            pst.setInt(1, idMascota);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                System.out.println("\n=== INFORMACIÓN DE MASCOTA ===");
                System.out.println("Nombre: " + rs.getString("nombre"));
                System.out.println("Dueño: " + rs.getString("dueno_nombre") + " " + rs.getString("apellido"));
                System.out.println("Especie: " + rs.getString("nombre_especie"));
                System.out.println("Raza: " + rs.getString("nombre_raza"));
                System.out.println("Sexo: " + rs.getString("sexo"));
                System.out.println("Edad: " + rs.getInt("edad") + " años");
                System.out.println("============================");
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener información: " + e.getMessage());
        }
    }

    public void cerrar() {
        try {
            if (conexion != null && !conexion.isClosed()) {
                conexion.close();
                System.out.println("Conexión cerrada");
            }
        } catch (SQLException e) {
            System.out.println("Error al cerrar conexión: " + e.getMessage());
        }
    }
}
